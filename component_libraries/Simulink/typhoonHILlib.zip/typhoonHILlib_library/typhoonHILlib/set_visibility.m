function set_visibility(param, visibility)
    % visibility = 'on', 'off'
    param.Visible = visibility;
end