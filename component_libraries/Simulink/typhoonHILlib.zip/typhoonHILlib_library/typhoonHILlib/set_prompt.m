function set_prompts(param, prompt)
    % prompt = 'string'
    param.Prompt = prompt;
end